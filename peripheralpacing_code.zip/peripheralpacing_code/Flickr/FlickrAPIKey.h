//
//  FlickrFetcher.h
//  Created for CS193p Spring 2011
//  Stanford University
//
//  Get your own key!
//

#define FlickrAPIKey @"292adbffafcba30e5d4448fa9937065b"
