//
//  main.m
//  BreatheUploader
//
//  Created by Poorna Krishnamoorthy on 9/4/11.
//  Copyright 2011 stanford university. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
