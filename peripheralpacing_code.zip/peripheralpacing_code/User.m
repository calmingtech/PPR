//
//  User.m
//  peripheralpacing
//
//  Created by Poorna Krishnamoorthy on 8/26/11.
//  Copyright 2011 stanford university. All rights reserved.
//

#import "User.h"


@implementation User
@synthesize userName, image;
@end
